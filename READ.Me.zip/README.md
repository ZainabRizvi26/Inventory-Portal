# Inventory Portal

A web-based inventory management system for tracking IT assets across office locations — including servers, laptops, printers, network equipment, CCTV cameras, and more.

## Screenshots

### Location Selection
Choose your office location to get started.

![Location Selection](screenshots/location-selection.png)

### Portal Type
Access as a regular user or an admin, depending on your role.

![Portal Type](screenshots/portal-type.png)

### Login
Secure login with username or email.

![Login](screenshots/login.png)

### Dashboard
A central hub to search and manage all inventory — accessories, port mappings, data centre assets, and more.

![Dashboard](screenshots/dashboard.png)

## Features

- 🏢 Multi-location support (e.g. Islamabad, Karachi offices)
- 🔐 Separate User and Admin portals with authentication (login, signup, forgot/reset password)
- 📊 Central dashboard with global search across equipment, accessories, and ports
- 🗄️ Asset management across multiple categories:
  - IT Accessories (Laptops, LCDs, Keyboards/Mice, Docking Stations)
  - Data Centre (Servers, Storage, Racks, environment monitoring)
  - Port Mapping (device-to-IP mapping, port status, connectivity tracking)
  - Network equipment (Switches, UPS, Network Printers, Printers)
  - CCTV Cameras & Access Control
- 👥 User management with admin controls
- 📱 Progressive Web App (PWA) support

## Tech Stack

**Frontend:** HTML, CSS, JavaScript
**Backend:** Node.js, Express.js
**Database:** MongoDB (via Mongoose models)

## Project Structure

```
Inventory-Portal/
├── server/
│   ├── models/       # Database models (User, AdminCode, etc.)
│   ├── routes/       # API routes (auth, users, accessories, etc.)
│   ├── middleware/   # Auth middleware
│   └── server.js     # Entry point
├── js/               # Frontend JavaScript
├── css/              # Stylesheets
├── images/           # App icons & images
├── screenshots/       # README screenshots
└── *.html            # Application pages
```

## Getting Started

1. Clone the repository:
   ```
   git clone https://github.com/ZainabRizvi26/Inventory-Portal.git
   ```
2. Install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   node server/server.js
   ```
4. Open `index.html` or navigate to the local server URL in your browser.

## Author

**Zainab Rizvi**
GitHub: [@ZainabRizvi26](https://github.com/ZainabRizvi26)
